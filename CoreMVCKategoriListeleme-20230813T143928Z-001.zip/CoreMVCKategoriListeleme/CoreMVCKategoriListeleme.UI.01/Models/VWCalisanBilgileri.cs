﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CoreMVCKategoriListeleme.UI._01.Models
{
    public partial class VWCalisanBilgileri
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public string City { get; set; }
    }
}
