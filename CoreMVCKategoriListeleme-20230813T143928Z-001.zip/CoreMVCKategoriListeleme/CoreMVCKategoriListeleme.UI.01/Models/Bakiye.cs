﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CoreMVCKategoriListeleme.UI._01.Models
{
    public partial class Bakiye
    {
        public int BakiyeId { get; set; }
        public decimal? Bakiye1 { get; set; }
        public string KullaniciAdi { get; set; }
    }
}
