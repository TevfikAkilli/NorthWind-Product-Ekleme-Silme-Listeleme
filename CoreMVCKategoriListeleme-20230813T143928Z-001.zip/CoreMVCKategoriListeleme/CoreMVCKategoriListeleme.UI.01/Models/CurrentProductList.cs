﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CoreMVCKategoriListeleme.UI._01.Models
{
    public partial class CurrentProductList
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
    }
}
