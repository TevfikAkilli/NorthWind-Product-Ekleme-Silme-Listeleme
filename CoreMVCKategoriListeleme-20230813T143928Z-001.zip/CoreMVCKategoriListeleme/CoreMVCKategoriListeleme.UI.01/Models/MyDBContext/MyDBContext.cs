﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreMVCKategoriListeleme.UI._01.Models.MyDBContext
{
    public class NORTHWND2Context : DbContext
    {
        public NORTHWND2Context(DbContextOptions<NORTHWND2Context> opt) : base(opt)
        {


        }

       
    }
}
