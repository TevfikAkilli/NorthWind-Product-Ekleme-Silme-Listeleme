﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreMVCKategoriListeleme.UI._01.Models.VM
{
    public class KategoriVM
    {
        public Category Kategori { get; set; }
    }
}
