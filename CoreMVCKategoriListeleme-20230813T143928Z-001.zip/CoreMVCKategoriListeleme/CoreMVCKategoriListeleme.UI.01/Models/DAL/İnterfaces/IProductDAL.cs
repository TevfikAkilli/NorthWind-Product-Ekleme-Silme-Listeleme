﻿using CoreMVCKategoriListeleme.UI._01.Models.DAL.Concrete;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreMVCKategoriListeleme.UI._01.Models.DAL.İnterfaces
{
   
    public interface IProductDAL
    {
          List<Product> UrunListele();
          void UrunEkle(Product k);
          void UrunSil(List<int> s);
        List<SelectListItem> UrunListeleListİtem();
        List<Product> UrunListeleByKategori(int id);

    }
}   
