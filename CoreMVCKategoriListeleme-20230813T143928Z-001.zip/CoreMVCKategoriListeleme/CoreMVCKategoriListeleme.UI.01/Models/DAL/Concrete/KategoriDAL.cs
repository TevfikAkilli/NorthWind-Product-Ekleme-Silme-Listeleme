﻿using CoreMVCKategoriListeleme.UI._01.Models.DAL.İnterfaces;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreMVCKategoriListeleme.UI._01.Models.DAL.Concrete
{
    public class KategoriDAL: IKategoriDAL
    {

        private readonly NORTHWND2Context _NORTHWND2Context;

        
        public KategoriDAL (NORTHWND2Context nORTHWND2Context)
        {
            _NORTHWND2Context = nORTHWND2Context;

        }

        public List<SelectListItem> KategoriListe()
        {

            List<SelectListItem> kategoriler = _NORTHWND2Context.Categories.Select(c=> new SelectListItem { 
            Value=c.CategoryId.ToString(),
            Text=c.CategoryName
            
            }).ToList();
            
            
            return kategoriler;

        }

        

    }
}
