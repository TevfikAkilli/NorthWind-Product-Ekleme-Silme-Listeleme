﻿using CoreMVCKategoriListeleme.UI._01.Models.DAL.İnterfaces;
using CoreMVCKategoriListeleme.UI._01.Models.VM;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreMVCKategoriListeleme.UI._01.Models.DAL.Concrete
{
    public class ProductDAL : IProductDAL
    {
        private readonly NORTHWND2Context _NORTHWND2Context;

        public ProductDAL(NORTHWND2Context NORTHWND2Context)
        {

            _NORTHWND2Context = NORTHWND2Context;
        }

        public List<Product> UrunListele()
        {

            List<Product> urunListesi = _NORTHWND2Context.Products.ToList();


            return urunListesi;
        }

        public void UrunEkle(Product k)
        {
            _NORTHWND2Context.Products.Add(k);
            _NORTHWND2Context.SaveChanges();

            return;
        }

        public void UrunSil(List<int> secilenUrunİdler)
        {
            foreach (var id in secilenUrunİdler)
            {
                var urunler = _NORTHWND2Context.Products.Where(a => a.ProductId == id);
                 
                foreach (var silinecekler in urunler)
                {
                    _NORTHWND2Context.Remove(silinecekler);
                     

                }
            }

            _NORTHWND2Context.SaveChanges();
        }

        public List<SelectListItem> UrunListeleListİtem()
        {

            List<SelectListItem> ürünler= _NORTHWND2Context.Products.Select(a => new SelectListItem
            {
                 Value= a.ProductId.ToString(),
                Text = a.ProductName
            }).ToList();

            return ürünler;
        }

        public List<Product> UrunListeleByKategori( int id )
        {
            List<Product> listem = _NORTHWND2Context.Products.Where(a => a.CategoryId == id).ToList();




            return listem;

               
        }
    }
}
