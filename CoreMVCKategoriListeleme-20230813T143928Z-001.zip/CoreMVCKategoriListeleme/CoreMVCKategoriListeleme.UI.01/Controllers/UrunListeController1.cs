﻿using CoreMVCKategoriListeleme.UI._01.Models;
using CoreMVCKategoriListeleme.UI._01.Models.DAL.Concrete;
using CoreMVCKategoriListeleme.UI._01.Models.DAL.İnterfaces;
using CoreMVCKategoriListeleme.UI._01.Models.VM;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreMVCKategoriListeleme.UI._01.Controllers
{
    public class UrunListeController1 : Controller
    {
        private IProductDAL _productDAL { get; set; }
        private IKategoriDAL _kategoriDAL { get; set; }
        public UrunListeController1(IProductDAL productDal, IKategoriDAL kategoriDAL)
        {
            _productDAL = productDal;
            _kategoriDAL = kategoriDAL;
        }
        public IActionResult Index()
        {

            ViewBag.Kategoriliste = _kategoriDAL.KategoriListe();
            if (TempData["liste"] != null)
            {

                var kategoriliListe = JsonConvert.DeserializeObject<List<Product>>(TempData["liste"].ToString());

                ViewBag.sonkategorililistele = kategoriliListe;
            }
            else
            {
                ViewBag.sonkategorililistele = _productDAL.UrunListele();
            }



            return View();
        }

        public IActionResult UrunEkle()
        {
            ViewBag.Kategoriliste = _kategoriDAL.KategoriListe();

            return View();
        }

        [HttpPost]
        public IActionResult UrunEkle(UrunVM filtredengelenler)
        {
            _productDAL.UrunEkle(filtredengelenler.Urun);
            return RedirectToAction("Index");
        }

        public IActionResult UrunSil()
        {

            ViewBag.Kategoriliste = _kategoriDAL.KategoriListe();
            if (TempData["silmelist"] != null)
            {
                var kategoriliListe = JsonConvert.DeserializeObject<List<Product>>(TempData["silmelist"].ToString());

                ViewBag.Silmelistele = kategoriliListe;
            }

            return View();
        }

        [HttpPost]
        public IActionResult UrunSil(List<int> selectedIds)
        {


            _productDAL.UrunSil(selectedIds);


            return RedirectToAction("UrunSil");
        }



        [HttpPost]
        public IActionResult KategoriyeGoreUrunFiltrele(KategoriVM id)
        {
            var list = _productDAL.UrunListeleByKategori(id.Kategori.CategoryId);
            TempData["liste"] = JsonConvert.SerializeObject(list);
            return RedirectToAction("Index");

        }


        [HttpPost]
        public IActionResult KategoriyeGoreUrunsilmefitre(KategoriVM id)
        {
            var silinecek = _productDAL.UrunListeleByKategori(id.Kategori.CategoryId);
            TempData["silmelist"] = JsonConvert.SerializeObject(silinecek);
            return RedirectToAction("UrunSil");

        }
    }
}
